/*
 * File:   main.c
 * Author: Edgar
 * Prelaboratory 10 - 3
 * Created on May 5th of 2023, 08:00 AM
 */

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#include <stdio.h>
#define _XTAL_FREQ 8000000

//=================================================
//Variables
int unit, tens, hundreds; 
int *pUnit = &unit;
int *pTens = &tens;
int *pHundreds = &hundreds;
char tempNumber;
int receive;
uint8_t portValue;

//=================================================
//Prototypes of functions and interruption 
void setup(void);
void cadena(char* txt);
void getDigits(int num);
void conversion(char *txt);

void __interrupt() isr(void) {
    //If a character is received in the USART module
    if(RBIF) {
        
        if(PORTBbits.RB6 == 0)
        {
            PORTD--;
            while(PORTBbits.RB6 == 0);
        }
        else if(PORTBbits.RB7 == 0)
        {
            PORTD++;
            while(PORTBbits.RB7 == 0);
        }

        getDigits(PORTD);
    
        RBIF = 0;
        
    }
    
    __delay_ms(50);
    
    if(RCIF == 1){
            portValue = RCREG;
            
        if (portValue != 0) {

        if (portValue >= 0 && portValue <= 255) {
                PORTA = portValue;
            }
            portValue = 0;
        }
            
            PIR1bits.RCIF = 0; // Borrar el indicador
        } 
}

//=================================================
//Main cycle
void main(void) {
    setup();
    
    while(1) {
                
        TXREG = hundreds + 48; // Enviar el valor de las centenas
        __delay_ms(30); 
                
        TXREG = tens + 48; // Enviar el valor de las decenas
        __delay_ms(30); 
                
        TXREG = unit + 48; // Enviar el valor de las unidades
        __delay_ms(30); 

        TXREG = '\n'; // Enviar nueva l�nea
        __delay_ms(10);

    }
}

//=================================================
void setup(void) {
    //Configuration of ports
    ANSEL = 0x00; //Digital inputs
    ANSELH = 0x00;
    
    TRISD = 0;
    PORTD = 0x00;
    
    TRISA = 0;
    PORTA = 0;
    
    TRISB = 0b11000000;
    PORTB = 0;
    
    OPTION_REGbits.nRBPU = 0; //enabling individual pull ups
    WPUBbits.WPUB7 = 1;
    WPUBbits.WPUB6 = 1;
    
    //Configuration of oscillator
    OSCCONbits.IRCF = 0b100; //1MHz
    OSCCONbits.SCS = 1;
    
    //Configuration of TX and RX
    TXSTAbits.SYNC = 0;  //0 and 1 for the table (at 1MHz)
    TXSTAbits.BRGH = 1;
    
    BAUDCTLbits.BRG16 = 1;
    
    SPBRG = 25;  //25 and 0 for the table (at 1MHz)
    SPBRGH = 0;  //?
    
    RCSTAbits.SPEN = 1; //Enabling serial communication
    RCSTAbits.RX9 = 0;  //Disabling the direction bit )8 bits instead of 9)
    RCSTAbits.CREN = 1; //Enabling reception
    
    TXSTAbits.TXEN = 1; //Enabling transmission
    
    //Configuration of TX and RX
    TXSTAbits.SYNC = 0;  //0 and 1 for the table (at 1MHz)
    TXSTAbits.BRGH = 1;
    
    BAUDCTLbits.BRG16 = 1;
    
    SPBRG = 25;  //25 and 0 for the table (at 1MHz)
    SPBRGH = 0;  //?
    
    RCSTAbits.SPEN = 1; //Enabling serial communication
    RCSTAbits.RX9 = 0;  //Disabling the direction bit )8 bits instead of 9)
    RCSTAbits.CREN = 1; //Enabling reception
    
    TXSTAbits.TXEN = 1; //Enabling transmission
    
    //Configuration of interruptions
    PIR1bits.RCIF = 0; //Flag of reception in 0 (still no reception)
    PIE1bits.RCIE = 1; //Reception (enable)
    IOCBbits.IOCB6 = 1; // Enabling interruptions in pins
    IOCBbits.IOCB7 = 1; //
    INTCONbits.RBIF = 0; //Flag of interruption in portB
    INTCONbits.RBIE = 1;
    INTCONbits.PEIE = 1; //Peripheral
    INTCONbits.GIE = 1; // Global   
    INTCONbits.RBIE = 1; //PortB interruption

}

//Function for sending a character string
void cadena(char *txt) {
    while(*txt != '\0') { //POinter starts at the first element
        while(TXSTAbits.TRMT == 0); //Waiting until the last character has been sent
        TXREG = *txt;
        txt++;    
        }
    }

void getDigits(int num) {
    *pHundreds = num / 100; //Getting hundreds
    num = num - (*pHundreds)*100;
    *pTens = num / 10; //Getting tens
    num = num - (*pTens)*10;
    *pUnit = num; //Getting units 
}




