# Import standard python modules
import sys
import time
import serial
import time

#Starting serial conexion
ser = serial.Serial('COM5', 9600)

#Verifying if the port is open
if ser.is_open:
    print("Port open correctly!")
else:
    print("Error opening the port!")

# Import Adafruit IO REST client and MQTTClient
from Adafruit_IO import Client, Feed, MQTTClient

# Set to your Adafruit IO key and username.
ADAFRUIT_IO_KEY = "aio_masB06bU6L4waWMOweR6TICYYveU"
ADAFRUIT_IO_USERNAME = "Edgar21120"

# Set the ID of the feeds to send and subscribe to for updates.
COUNTER_FEED_ID = "counter-1-pic"
PORTD_FEED_ID = "puerto-pic"

# Create an instance of the REST client.
aio = Client(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)

# Variables to hold the count for the feeds
counter = 0
valor_str = 0

# Create an MQTT client instance.
client = MQTTClient(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)

#Updating values in Adafruit
def message(client, feed_id, payload):
    global port
    
    #print("Value of the Feed {0} is: {1}".format(feed_id, payload))
    
    #Uploading the value of sensors
    if feed_id == PORTD_FEED_ID:
        port = int(payload)

# Define callback functions for the MQTT client.
def connected(client):

    print("Subscribing to Feed {0}".format(COUNTER_FEED_ID))
    client.subscribe(COUNTER_FEED_ID)
    print("Waiting for feed data...")

    print("Subscribing to Feed {0}".format(PORTD_FEED_ID))
    client.subscribe(PORTD_FEED_ID)
    print("Waiting for feed data...")

#For making the disconnection to Adafruit
def disconnected(client):
    sys.exit(1)

# Setup the callback functions defined above.
client.on_connect = connected
client.on_disconnect = disconnected
client.on_message = message

# Connect to the Adafruit IO server.
client.connect()

# Start the MQTT client's background thread to listen for messages.
client.loop_background()

#Getting the value of the port
feed = aio.feeds("puerto-pic")

while True:
    #Processing and printing the value of the counter
    counter = ser.readline().strip()
    valor_str = counter.decode()
    print("Value of the counter:", valor_str)
    time.sleep(1)

    #Printing the value of the port
    value = aio.receive(feed.key).value
    aio.send_data(COUNTER_FEED_ID, valor_str)
    print("Value of the port: ", value)

    #Sending the value of the port via serial
    value_byte = bytes([int(value)])
    ser.write(value_byte)

    # Adafruit IO is rate-limited for publishing,
    # so we'll need a delay for calls to aio.send_data()
    time.sleep(1)

