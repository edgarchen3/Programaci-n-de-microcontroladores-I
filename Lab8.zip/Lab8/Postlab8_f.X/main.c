/*
 * File:   main.c
 * Author: Edgar Chen
 * Postlaboratory 8
 * Created on 13 of April of 2023, 23:46
 */

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#include <stdio.h>
#define _XTAL_FREQ 8000000

//=================================================
//Variables
const char data[] = "THIS IS THE LAB";
char action;
char potentiometer;
char valuePot[3];
int adc;

//=================================================
//Prototypes of functions and interruption 
void setup(void);

void cadena(char* txt);

//=================================================
//Main cycle
void main(void) {
    setup();
    
    while(1) {  
        //Actions
        cadena("\rWhich action would you like to do?\r");
        cadena("1.To read a potentiometer\r");
        cadena("2.To send an Ascii\r");
        
        while(PIR1bits.RCIF == 0); //Waiting for a data
        
        action = RCREG; //Saving the data
        
        switch(action) {//Implementing the decision 
            //Reading potentiometer
            case('1'):
                //Starting the ADC conversion 
                ADCON0bits.CHS = 0;
                ADCON0bits.GO = 1;
                while(ADCON0bits.GO);
                adc = (ADRESH << 8) | ADRESL;
                potentiometer = (char)(adc >> 2);
                sprintf(valuePot, "%d", potentiometer);
                //Showing the value
                cadena("The value of the potentiometer is: ");
                cadena(valuePot);
                cadena("\r");
                break;
                
            //Receiving the character
            case('2'):
                //Showing the character in the PortB
                cadena("Enter a character: ");
                while(PIR1bits.RCIF == 0);
                PORTB = RCREG;
                break;
        }
    }
}

//=================================================
void setup(void) {
    //Configuration of ports
    ANSEL = 0b00000001; //Digital inputs
    ANSELH = 0x00;
    
    TRISA = 0b00000001;
    
    TRISB = 0;
    TRISD = 0;
    PORTB = 0x00;
    
    //Configuration of oscillator
    OSCCONbits.IRCF = 0b100; //1MHz
    OSCCONbits.SCS = 1;
    
    //Configuration of TX and RX
    TXSTAbits.SYNC = 0;  //0 and 1 for the table (at 1MHz)
    TXSTAbits.BRGH = 1;
    
    BAUDCTLbits.BRG16 = 1;
    
    SPBRG = 25;  //25 and 0 for the table (at 1MHz)
    SPBRGH = 0;  //?
    
    RCSTAbits.SPEN = 1; //Enabling serial communication
    RCSTAbits.RX9 = 0;  //Disabling the direction bit )8 bits instead of 9)
    RCSTAbits.CREN = 1; //Enabling reception
    
    TXSTAbits.TXEN = 1; //Enabling transmission
    
    //Configuration of interruptions
    PIR1bits.RCIF = 0; //Flag of reception in 0 (still no reception)
    PIE1bits.RCIE = 1; //Reception (enable)
    INTCONbits.PEIE = 1; //Peripheral
    INTCONbits.GIE = 1; // Global  
    
    //ADC configuration
    ADCON1bits.ADFM = 1;    //Justified to the right
    ADCON1bits.VCFG0 = 0;   //Reference voltages of 0 and 5V
    ADCON1bits.VCFG1 = 0;
    ADCON0bits.ADCS = 0b10; //ADC Clock Fosc/32 
    ADCON0bits.CHS = 0;     //Channel 0
    __delay_ms(50);
    ADCON0bits.ADON = 1; 
    
}

//Function for sending a character string
void cadena(char *txt) {
    while(*txt != '\0') { //POinter starts at the first element
        while(TXSTAbits.TRMT == 0); //Waiting until the last character has been sent
        TXREG = *txt;
        txt++;        
    }
}


