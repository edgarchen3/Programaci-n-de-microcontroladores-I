#include <xc.h>
#include "PWM.h"
#define _XTAL_FREQ 8000000

void PWM_config(char canal, float periodo_ms) {
    
        //Configuring ADC
    ADCON1bits.ADFM = 0;    //Justified to the left
    ADCON1bits.VCFG0 = 0;   //Reference voltages of 0 and 5V
    ADCON1bits.VCFG1 = 0;
    
    ADCON0bits.ADCS = 0b10; //ADC Clock Fosc/32 
    ADCON0bits.CHS = canal;     //Channel 0
    ADCON0bits.ADON = 1;    //Turning on the module
    __delay_ms(50);
        
    PR2 = periodo_ms;            //Period of tmr2 (4ms) (250)
    
    CCP1CONbits.P1M = 0;  //Single output mode
    CCP1CONbits.CCP1M = 0b00001100; //PWM mode
    
    CCP2CONbits.CCP2M = 0b00001100; //PWM mode
    
    CCP1CONbits.DC1B0 = 0; //less significative bits
    CCP1CONbits.DC1B1 = 0;
    CCP2CONbits.DC2B0 = 0;
    CCP2CONbits.DC2B1 = 0;
    
    PIR1bits.TMR2IF = 0;        //Flag off
    T2CONbits.T2CKPS = 0b11;    //Preescaler 1:16
    T2CONbits.TMR2ON = 1;       //Turning on tmr2
    
}

void PWM_duty(char canal, int justification) {
    
    ADCON0bits.CHS = canal;
    CCPR1L = justification;      //duty cycle start
    CCPR2L = justification;
}