/*
 * File:   main.c
 * Author: Edgar Chen
 * Postlab 7
 * Created on 1 de abril de 2023, 13:57
 */

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

//Libraries
#include <xc.h>
#include <stdint.h>
#include "PWM.h"
#include "LED.h"
#define _XTAL_FREQ 8000000
#define _tmr0_value 250

//Variables
char motor;
int counter_tmr0, led; 

void setup(void);

//Interruption
void __interrupt() isr (void) {
    
    if(T0IF) {
        counter_tmr0++;
        TMR0 = _tmr0_value;
        INTCONbits.T0IF = 0;
        PIR1bits.TMR1IF = 0;
        
        if(counter_tmr0 >= led) {
            portLED(0, 3);  //Output disabled
            counter_tmr0 = 0;
        }
        else {
            portLED(1, 3);;  //Enabled output
        }
    }
    
    //When the conversion is complete
    if (PIR1bits.ADIF) {
        
        //Controlling the frequency of the module CCP1
        if(ADCON0bits.CHS == 1) {
            CCPR1L = (ADRESH >> 1) + 124;
        }
        
        //Controlling the frequency of the module CCP2
        else if(ADCON0bits.CHS == 0) {
            CCPR2L = (ADRESH >> 1) + 124;
        }
        
        else{
            led = ADRESH;
        }
        
        //Turning off the conversion 
        PIR1bits.ADIF = 0;
    }
}

void main(void) {
    
    setup();
    
    ADCON0bits.GO = 1;
    
    while (1) {
        
        if(ADCON0bits.GO == 0) { //When the conversion has finished
            
            if(ADCON0bits.CHS == 0) {
                ADCON0bits.CHS = 1;
        }
            else if(ADCON0bits.CHS == 1) {
                ADCON0bits.CHS = 2;
            }
            else {
                ADCON0bits.CHS = 0;
                motor = 2;
            }
            
            __delay_ms(50); //Waiting, because of the change of channel
            
            ADCON0bits.GO = 1;
        }
    }     
    return;
}

void setup(void) {
    ANSEL = 0b00000111; //ANS0 as analogic input
    ANSELH = 0x00;         //PORTB USED AS DIGITAL        
    
    TRISA = 0b00000111;       //RA0 and RA1 AS INPUTS
    TRISC = 0;       //
    TRISD = 0;
       
    //Configuring the oscillator 8MHz and internal
    OSCCONbits.IRCF2 = 1;
    OSCCONbits.IRCF1 = 1;
    OSCCONbits.IRCF0 = 1;
    OSCCONbits.SCS = 1;
    
    //Configuring PWM
    TRISCbits.TRISC3 = 1; //CCP2 as input
    TRISCbits.TRISC2 = 1; //RC2/CCP2 as input
    TRISCbits.TRISC1 = 1; //CCP2 as input
    
    PWM_config(0, 250);
    PWM_duty (0, 0x0F);

    while (!PIR1bits.TMR2IF == 0);   //Wait one cycle
    
    PIR1bits.TMR2IF = 0;
    TRISCbits.TRISC2 = 0;       //CCP1 as output  
    TRISCbits.TRISC1 = 0; //CCP2 as output
    TRISCbits.TRISC3 = 0;

    
    //Configuring interruptions
    PIR1bits.ADIF = 0;  //Flag of ADC conversion
    PIE1bits.ADIE = 1;  //Enabling ADC conversion
    INTCONbits.PEIE = 1;    //Peripheral Interruption
    INTCONbits.T0IE = 1;
    INTCONbits.GIE = 1;     //Global interruptions
    ADCON0bits.GO = 1;      //Starts the ADC conversion
    
    //Timer0 configuration
    OPTION_REGbits.T0CS = 0;
    OPTION_REGbits.T0SE = 0;
    OPTION_REGbits.PSA = 0;
    OPTION_REGbits.PS = 0b111;
    TMR0 = _tmr0_value;
    INTCONbits.T0IF = 0;
    
    motor = 1; //Starting at motor 1
    
    counter_tmr0 = 0;
}