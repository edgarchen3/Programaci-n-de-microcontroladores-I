#include <xc.h>
#include "LED.h"
#define _XTAL_FREQ 8000000

//Variables

//Functions
void portLED(int state, int port){
    
    switch(port){
        case 0:
            PORTCbits.RC0 = state;
            break;
        case 1:
            PORTCbits.RC1 = state;
            break;
        case 2:
            PORTCbits.RC2 = state;
            break;
        case 3:
            PORTCbits.RC3 = state;
            break;
        case 4:
            PORTCbits.RC4 = state;
            break;
        case 5:
            PORTCbits.RC5 = state;
            break;
        case 6:
            PORTCbits.RC6 = state;
            break;
        case 7:
            PORTCbits.RC7 = state;
            break;
    }
}
