/*
 * File:   main.c
 * Author: Edgar
 * Lab 9 final 2
 * Created on 21 de abril de 2023, 08:51 AM
 */

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#define _XTAL_FREQ 4000000
#define dirEEPROM 0x01

//=================================================
//Variables
uint8_t potValue = 0;
uint8_t state = 0; //1 sleeping, 0 not sleeping


//=================================================
//Prototypes of functions and interruption 
void setup(void);
void writeToEEPROM(uint8_t data, uint8_t addres);
uint8_t readFromEEPROM(uint8_t address);

void __interrupt() isr (void) {
    
    if (INTCONbits.RBIF) { //If there is interruptions in the portB
        
        if (PORTBbits.RB0 == 0) { //The PIC is waked up
            state = 0;
        }
        if (PORTBbits.RB1 == 0) { //Sleep mode turned on
            state = 1;
            SLEEP();
        }
        if(PORTBbits.RB2 == 0) { //Saving the Data in the EEPROM and showing it in the PORTD
            state = 0;
            writeToEEPROM(potValue, dirEEPROM);
            PORTD = readFromEEPROM(dirEEPROM);
        }
        INTCONbits.RBIF = 0;
    } 
    
    if (PIR1bits.ADIF) { //Interruption in the ADC (conversion has finished)
        if (ADCON0bits.CHS == 0) { //If the interruption is in the channel 0
            potValue = ADRESL;
            PORTC = potValue; //Value of the potentiometer in portC
        }
        PIR1bits.ADIF = 0;
    }
    
}

//=================================================
//Main cycle

void main(void) {
    
    setup();
    PORTD = readFromEEPROM(dirEEPROM);

    while(1) {
        if (state == 0) { //If PIC is not sleeping
            if (ADCON0bits.GO == 0) { //If there is no conversion
                ADCON0bits.GO = 1; //The conversion starts
                __delay_us(50);
            }
        }
    }
}

//=================================================
//Setup

void setup(void) {
    ANSEL = 0b00000001; //AN0 as analogic input
    ANSELH = 0x00;
    
    TRISA = 0x01;
    TRISB = 0b00000111; //B0, B1 and B2 as inputs
    TRISC = 0x00;
    TRISD = 0x00;
    
    PORTA = 0x00;
    PORTB = 0x00;
    PORTC = 0x00;
    PORTD = 0x00;
    
    //Interruptions
    INTCONbits.RBIE = 1;
    INTCONbits.RBIF = 0;
    IOCBbits.IOCB0 = 1;
    IOCBbits.IOCB1 = 1;
    IOCBbits.IOCB2 = 1;
    INTCONbits.PEIE = 1; //Peripheral
    INTCONbits.GIE = 1;
    PIR1bits.ADIF = 1;
    PIE1bits.ADIE = 1;
    
    //Configuring pull ups
    OPTION_REGbits.nRBPU = 0; //enabling individual pull ups
    WPUBbits.WPUB0 = 1; //enabling pull ups in B0, B1 and B2
    WPUBbits.WPUB1 = 1;
    WPUBbits.WPUB2 = 1;
    
    //Configuring oscillator 4MHz
    OSCCONbits.IRCF2 = 1;
    OSCCONbits.IRCF1 = 1;
    OSCCONbits.IRCF0 = 0;
    OSCCONbits.SCS = 1; //internal
    
    //Configuring ADC
    ADCON0bits.ADCS = 1; //ADC Fosc/8
    ADCON1bits.VCFG0 = 0; //Reference voltages
    ADCON1bits.VCFG1 = 0;
    ADCON0bits.CHS = 0;   
    ADCON1bits.ADFM = 1; //JUstified to the right
    ADCON0bits.ADON = 1; //Enabling ADC module
    __delay_us(50);
}

//=================================================
//Functions
void writeToEEPROM(uint8_t data, uint8_t address) {
    EEADR = address;
    EEDAT = data;
    
    EECON1bits.EEPGD = 0; //writing in data memory
    EECON1bits.WREN = 1; //Enabling writing 
    
    INTCONbits.GIE = 0; //Disabling interruptions
    
    EECON2 = 0x55; //Security sequence
    EECON2 = 0xAA; 
    EECON1bits.WR = 1; //Writing
    
    EECON1bits.WREN = 0; //Disabling EEPROM writing
    INTCONbits.RBIF = 0;
    INTCONbits.GIE = 1; //Enabling interruptions
}

uint8_t readFromEEPROM(uint8_t address) {
    EEADR = address;
    EECON1bits.EEPGD = 0; //getting the data from the EEPROM
    EECON1bits.RD = 1;    
    return EEDAT; 
}


