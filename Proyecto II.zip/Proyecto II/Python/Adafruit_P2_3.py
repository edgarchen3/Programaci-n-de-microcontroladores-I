# Import standard python modules
import time
import serial
import sys

#Starting serial conexion
ser = serial.Serial('COM5', 9600)

#Verifying if the port is open
if ser.is_open:
    print("Port open correctly!")
else:
    print("Error opening the port!")

# Import Adafruit IO REST client and MQTTClient
from Adafruit_IO import Client, MQTTClient

#Keeeps the count for the feed
run_count = 0

# Set to your Adafruit IO key and username.
ADAFRUIT_IO_KEY = 'aio_RnSx05Vi6gofkd5yelJMTb4JHeFa'
ADAFRUIT_IO_USERNAME = 'Edgar21120'

# Create an instance of the REST client.
aio = Client(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)

# Set the ID of the feeds to send and subscribe to for updates.
FEED_ID1 = 'servo-1'
FEED_ID2 = 'servo-2'
FEED_ID3 = 'servo-3'
FEED_ID4 = 'servo-4'
FEED_ID5 = 'servo-5'
FEED_ID6 = 'servo-6'

# Define callback functions for the MQTT client.
def connected(client):
    client.subscribe(FEED_ID1)
    client.subscribe(FEED_ID2)
    client.subscribe(FEED_ID3)
    client.subscribe(FEED_ID4)
    client.subscribe(FEED_ID5)
    client.subscribe(FEED_ID6)
    #print('Waiting for the feed...')

def disconnected(client):
    """When the client disconects."""
    sys.exit(1)

def message(client, feed_id, payload):
    """When the value of a feed changes
    feed_id identifies the feed and payload has the new value"""

    #Payload converted to bytes and wrote it in serie
    ser.write(bytes(str(payload),'utf-8')) 
    print('Feed {0} has a new value of: {1}'.format(feed_id, payload))

#Creates an instance of MQTT client.
client = MQTTClient(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)

# Sets callback functions 
client.on_connect = connected
client.on_disconnect = disconnected
client.on_message = message

# Connecting to Adafruit IO server.
client.connect()

# Keep conversation while other messages are recivied
client.loop_blocking()

while True:
    var = "doing nothing here"