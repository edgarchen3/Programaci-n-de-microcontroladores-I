#Importing modules and lybraries
from PySide2.QtCore import QTimer
from PySide2.QtWidgets import QMainWindow, QApplication, QAbstractItemView
from InterfacePC_2 import Ui_Form
import serial

class MainWindow(QMainWindow, Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.serial_port = None
        #Indicating values used in each button
        self.pushButton.clicked.connect(self.connect_port)
        self.pushButton_2.clicked.connect(self.close_port)
        self.pushButton_3.clicked.connect(lambda: self.send_data('1'))
        self.pushButton_4.clicked.connect(lambda: self.send_data('2'))
        self.pushButton_5.clicked.connect(lambda: self.send_data('3'))
        self.pushButton_6.clicked.connect(lambda: self.send_data('4'))
        self.pushButton_7.clicked.connect(lambda: self.send_data('5'))
        self.pushButton_8.clicked.connect(lambda: self.send_data('6'))
        

        self.refresh_ports()

    #Cleaning ports
    def refresh_ports(self):
        ports = self.get_available_ports()
        self.comboBox.clear()
        self.comboBox.addItems(ports)

    #Applying ranges to COM
    def get_available_ports(self):
        available_ports = []
        for i in range(13):  # Range of COM0 to COM12
            port_name = f"COM{i}"
            available_ports.append(port_name)
        return available_ports

    #Making connection
    def connect_port(self):
        selected_port = self.comboBox.currentText()
        try:
            self.serial_port = serial.Serial(selected_port, 9600)
            print(f"Connected to {selected_port}")
        except serial.SerialException as e:
            print(f"Failed to connect to {selected_port}: {e}")

    #Closing connection
    def close_port(self):
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()
            print("Serial port closed")

    #Sending data encoded
    def send_data(self, data):
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.write(data.encode())
            print(f"Sent data: {data}")

#Initializing the program
if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    mainWindow = MainWindow()
    mainWindow.show()
    sys.exit(app.exec_())
