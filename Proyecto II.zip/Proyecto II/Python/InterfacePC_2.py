# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Interfaz_2.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

#Objects and its positions
class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(379, 297)
        #Pushes of connection and disconnection
        self.pushButton = QPushButton(Form)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(140, 20, 93, 28))
        self.pushButton_2 = QPushButton(Form)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(250, 20, 93, 28))
        #Box for selecting the COM port
        self.comboBox = QComboBox(Form)
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setGeometry(QRect(50, 20, 73, 22))
        #Remaining buttons
        self.pushButton_3 = QPushButton(Form)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setGeometry(QRect(20, 80, 91, 81))
        self.pushButton_4 = QPushButton(Form)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setGeometry(QRect(140, 80, 91, 81))
        self.pushButton_5 = QPushButton(Form)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setGeometry(QRect(270, 80, 91, 81))
        self.pushButton_6 = QPushButton(Form)
        self.pushButton_6.setObjectName(u"pushButton_6")
        self.pushButton_6.setGeometry(QRect(20, 190, 91, 81))
        self.pushButton_7 = QPushButton(Form)
        self.pushButton_7.setObjectName(u"pushButton_7")
        self.pushButton_7.setGeometry(QRect(140, 190, 91, 81))
        self.pushButton_8 = QPushButton(Form)
        self.pushButton_8.setObjectName(u"pushButton_8")
        self.pushButton_8.setGeometry(QRect(270, 190, 91, 81))

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        #Work of each element
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.pushButton.setText(QCoreApplication.translate("Form", u"CONNECT", None))
        self.pushButton_2.setText(QCoreApplication.translate("Form", u"DISCONNECT", None))
        self.pushButton_3.setText(QCoreApplication.translate("Form", u"Servo 1", None))
        self.pushButton_4.setText(QCoreApplication.translate("Form", u"Servo 2", None))
        self.pushButton_5.setText(QCoreApplication.translate("Form", u"Servo 3", None))
        self.pushButton_6.setText(QCoreApplication.translate("Form", u"Servo 4", None))
        self.pushButton_7.setText(QCoreApplication.translate("Form", u"Servo 5", None))
        self.pushButton_8.setText(QCoreApplication.translate("Form", u"Servo 6", None))
    # retranslateUi
